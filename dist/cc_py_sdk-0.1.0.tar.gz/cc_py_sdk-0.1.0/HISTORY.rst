=======
History
=======

0.1.0 (2024-11-08)
------------------

* First release on PyPI.
