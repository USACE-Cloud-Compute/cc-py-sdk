tests package
=============

Submodules
----------

tests.test\_plugin\_manager module
----------------------------------

.. automodule:: tests.test_plugin_manager
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tests
   :members:
   :undoc-members:
   :show-inheritance:
