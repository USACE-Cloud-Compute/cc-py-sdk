=====
Usage
=====

To use cc-py-sdk in a project::

    import cc_py_sdk
